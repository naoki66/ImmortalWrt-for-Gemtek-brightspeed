# B17 原始日志脱敏副本与中文解读

本包保留采集时的原始消息、时间戳、错误码和数值，英文内核消息不翻译替换。中文结果和阅读索引见本文件及“日志中文解读.md”。它是**原始日志的脱敏副本**，不是未经处理的原文件；本地原件未改动。

## 脱敏范围

IP、MAC、boot ID、SSID、主机名和URL用稳定占位符替换。凭据字段所在行整行移除，未公开节点YAML、订阅、SSH凭据、抓包和进程socket表，也不公开反向映射。source-public-manifest.json记录每个本地源文件与公开副本的字节数及SHA256，可核验副本来源。该清单不包含原始标识符。

## 原始日志阅读索引

| 文件 | 中文说明 |
| --- | --- |
| router/dmesg-initial.log、dmesg-post-test.log | 启动及结束后的内核原文，可核对PHY校准、NPU初始化和MCU/PCIe错误 |
| router/router.log | 路由器系统日志，含hostapd关联/断开及接口事件 |
| router/critical.log | 超时、PCIe AER、重置失败等关键事件筛选日志；本次文件为空 |
| router/telemetry.log | 每30秒的PCIe协商、负载、内存、无线station和字节计数 |
| router/server.log | 路由器端iperf3服务器的原始输出 |
| client/iperf-results.jsonl | 39轮完整结果，统计使用接收端数据 |
| client/iperf-intervals.jsonl* | 客户端保留的轮转区间原始记录，仅覆盖保留窗口 |
| client/wifi-samples.jsonl* | 电脑无线状态采样；SSID已替换为TEST_5G |
| client/proxy-results-final.log | 全部Trojan/HTTPS请求结果、哈希、证书校验及硬件中断前后值 |
| client/hardware-active-tests.log | 实机加密后端自测、ADC采样、PCIe和分区原文 |
| client/quiet-thermal-check.log | 空闲无线ADC温度和缓存状态计数 |
| client/post-test-audit.log | 停测后进程退出、boot ID、PCIe及错误检查 |

轮转会丢弃超出保留窗口的客户端区间明细，39轮结束汇总和完整代理请求记录保留。不能把“保留的区间日志”描述为全程每一秒明细。

## 特殊记录

最初3次代理请求因测试实例尚未就绪失败，修正等待就绪后成功85次。00:49:53的一次HTTPS请求为了采样握手而手动限制到65536字节/秒，不参与代理速度均值。抓到的TLS握手没有归属到独立测试进程，不据此认定该Trojan节点使用何种加密套件。Wi-Fi轮次间有短暂间隔与温度验收暂停，不计为掉线。
